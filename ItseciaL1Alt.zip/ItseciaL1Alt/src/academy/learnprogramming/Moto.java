package academy.learnprogramming;

import java.util.LinkedList;
import java.util.List;

public class Moto extends DeuxRoues {
    private int puissance;
    private String fabricant;
    private String modele;

    public Moto(int puissance, String fabricant, String modele) {
        this.puissance = puissance;
        this.fabricant = fabricant;
        this.modele = modele;
    }

    public int getPuissance() {
        return puissance;
    }

    public String getFabricant() {
        return fabricant;
    }

    public String getModele() {
        return modele;
    }

    @Override
    public void planer(int  toto) {
        System.out.println("planee");
    }

    @Override
    public void cabrer() {
        System.out.println("cabrer");
    }

    @Override
    public void roule() {
        System.out.println("rouler");
    }

    @Override
    public void freiner() {
        System.out.println("freiner");
    }

    @Override
    public void printDeuxRoues() {
        super.printDeuxRoues();
        //System.out.println(" Moto "+this.getFabricant() + " / " + this.getModele());
    }

    public static void main(String[] args) {
        Moto moto = new Moto(4, "Yamaha","XF400");

        String myStr = "la valeur de la variable est non nulle";
        System.out.println(myStr.substring(0,7));
        String myOtherString = "les ArrayList et les Linkedlist";
        if ( myStr.startsWith("la")) {

        }

        char myChar = myStr.charAt(8);

        if (myStr.equals(myOtherString)) {
            System.out.println("vrai");
        }

        String [] myTab = myStr.split(" ");
        for (String element:myTab){
            System.out.println(element);
        }

        int x = 5;
        int y = 7;

        if (x == y ){

        }

        if (moto instanceof DeuxRoues){
            System.out.println("vrai");
        } else {
            System.out.println("false");
        }

        Integer myInt = 6;
        int myOtherInt = 8;
        int x1 = myInt.intValue();

        List<Moto> list = new LinkedList<>();
    }

}

