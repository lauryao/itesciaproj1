package academy.learnprogramming;

import java.util.LinkedList;
import java.util.List;

public class PC {
    private String model;
    private String fabriquant;
    private CarteMere carteMere;  // List<CarteMere>  listeCartemere = new LinkedList<CartmeMere>();
    private Moniteur moniteur;

    public PC(String model, String fabriquant, CarteMere carteMere, Moniteur moniteur) {
        this.model = model;
        this.fabriquant = fabriquant;
        this.carteMere = carteMere;
        this.moniteur = moniteur;
    }

    public String getModel() {
        return model;
    }

    public String getFabriquant() {
        return fabriquant;
    }

    public CarteMere getCarteMere() {
        return carteMere;
    }

    public Moniteur getMoniteur() {
        return moniteur;
    }

    public void lancerProgramme(){
        this.moniteur.afficherImage();
    }

    public static void main(String[] args) {
        List<CarteMere> listCarteMere = new LinkedList<>();

        CarteMere carteMere = new CarteMere("sanyo","Sony",8, "x86");
        listCarteMere.add(carteMere);

        Moniteur moniteur = new Moniteur("XC234","SAMSUNG", 19, 1932);
        PC monPC = new PC("Thinkpad","LENOVO", carteMere, moniteur);


    }


}
