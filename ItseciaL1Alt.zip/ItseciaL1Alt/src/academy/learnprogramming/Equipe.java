package academy.learnprogramming;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class Equipe {
    private String name;
    private String ville;
    private List<Joueur> listeJoeur = new LinkedList<>();


    public Equipe(String name, String ville) {
        this.name = name;
        this.ville = ville;
        this.listeJoeur.add(new Joueur("Gilbert", 29, "France"));
        this.listeJoeur.add(new Joueur("Albert", 23, "France"));
        this.listeJoeur.add(new Joueur("Patrick", 25, "Allemagne"));
    }


    public String getName() {
        return name;
    }

    public String getVille() {
        return ville;
    }

    public List<Joueur> getListeJoeur() {
        return listeJoeur;
    }

    public void addJoueur(Joueur joueur){
        this.listeJoeur.add(joueur);
    }

    public void printListeJoueur(){
        System.out.println("joueurs de lequipe "+this.name);
        for (Joueur joueur:this.listeJoeur){
            System.out.println("\t"+ joueur.getName()+ " "+joueur.getPays());
        }
    }
}
