package academy.learnprogramming;

public class Cours implements InterfaceCours {
    private String intitule;
    private String code;
    private String description;

    public Cours(String intitule, String code) {
        this.intitule = intitule;
        this.code = code;
        this.description = "description par defaut";
    }

    public Cours(String intitule, String code, String description) {
        this.intitule = intitule;
        this.code = code;
        this.description = description;
    }

    public String getIntitule() {
        return intitule;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return (this.code+ " / "+this.intitule+ " / "+this.description);
    }

    @Override
    public void intituleCours() {
        System.out.println("Intitule");
    }

    @Override
    public String professeurCours(String code) {
        return null;
    }
}
