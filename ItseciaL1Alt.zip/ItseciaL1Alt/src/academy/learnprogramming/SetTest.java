package academy.learnprogramming;

import java.util.HashSet;
import java.util.Set;

public class SetTest {
    public static void main(String[] args) {

        Set<String> set = new HashSet<>();
        Set<String> set1 = new HashSet<>();

        String[] phrace1 = {"la","maison",""};

        set.add("la");
        set.add("maison");
        set.add("dans");
        set.add("la");
        set.add("vallee");

        set1.add("le");
        set1.add("toit");
        set1.add("de");
        set1.add("la");
        set1.add("maison");

        //Intersection
        //set1.retainAll(set);
        //Union
        //set1.addAll(set);
        //difference
        set1.removeAll(set);

        for (String s:set1){
            System.out.println(s);
        }

    }
}
