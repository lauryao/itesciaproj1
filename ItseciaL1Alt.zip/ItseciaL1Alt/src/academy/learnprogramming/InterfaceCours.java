package academy.learnprogramming;

public interface InterfaceCours {
    public int CoursID = 0;
    public void intituleCours();
    public String professeurCours(String code);
}
