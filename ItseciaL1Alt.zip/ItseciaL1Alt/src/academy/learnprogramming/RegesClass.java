package academy.learnprogramming;

public class RegesClass {

    public static void main(String[] args) {
        String myString = "je suis votre ami. Le savez-vous?";
        System.out.println(myString);
        String yourString = myString.replaceAll("je", "Nous");
        System.out.println(yourString);
        String alphanumeric = "abcDeeeF12Ghhiiiijkl99z";
        System.out.println(alphanumeric.replaceAll(".","Y"));
        System.out.println(alphanumeric.replaceAll("^abcDeee","YYY"));
        String secondString = "abcDeeeF12GhhabcDeeeiiiijkl99z";
        System.out.println(secondString.replaceAll("^abcDeee","YYY"));
        System.out.println(alphanumeric.matches("^hello"));
        String numTel = "01 26 26 26";
        System.out.println(numTel.matches("^(\\d\\d\\s*){4}$"));
        System.out.println(numTel.matches("^([0-9])+([.])*.*[0-9]$"));

        String email = "laurent.yao@yahoo.fr";
        System.out.println(email.matches("^(\\w)+([.])(\\w)+(([-])?(\\w)*)?([@])(\\w)+([.])(\\w)+$"));
        }
        }