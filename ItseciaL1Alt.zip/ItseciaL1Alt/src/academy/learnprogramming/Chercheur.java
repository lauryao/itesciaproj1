package academy.learnprogramming;

public class Chercheur extends Enseignant {

    public Chercheur(String nom) {
        super(nom);
    }


}
