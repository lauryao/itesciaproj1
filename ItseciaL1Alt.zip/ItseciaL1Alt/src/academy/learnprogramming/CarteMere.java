package academy.learnprogramming;

public class CarteMere {
    private String model;
    private String fabriquant;
    private int nbEmplRam;
    private String archi;

    public CarteMere(String model, String fabriquant, int nbEmplRam, String archi) {
        this.model = model;
        this.fabriquant = fabriquant;
        this.nbEmplRam = nbEmplRam;
        this.archi = archi;
    }

    public void demarrerSysteme(){
        System.out.println("Demerrer");
    }

    public void arreterSysteme(){
        System.out.println("Arreter");
    }
}
