package academy.learnprogramming;

public class Enseignant {
    private String  nom;
    private String numSecSociale;

    public Enseignant(String nom) {
        this.nom = nom;
        this.numSecSociale = "";
    }

    public final void printDonneesEnseignant(){
        System.out.println("nom "+ this.nom);
    }

}
