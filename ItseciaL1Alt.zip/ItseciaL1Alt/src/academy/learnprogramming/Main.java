package academy.learnprogramming;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Main{

    public static void main(String[] args) {

//        for (String param:args) {
//            System.out.print("param   "+param);
//        }

//        int num = 5;
//        int denom = 0;
//
//        try {
//            System.out.println(" resultat = " + divise1(num, denom));
//        } catch (ArithmeticException e) {
//            throw new ArithmeticException();
//        }
//
//    }
//
//    public static int divise(int x, int y){
//        if (y == 0){
//            return 0;
//        } else {
//            return (x/y);
//        }

//        TeamList teamList = new TeamList();
//        teamList.addTeam("PSG");
//        teamList.addTeam("OM");
//        teamList.addTeam("OL");
//
//        teamList.printTeamList();

        Equipe equipe = new Equipe("psg","paris");
        equipe.getListeJoeur().add(new Joueur("Lulu",19, "Belgique"));
        equipe.getListeJoeur().add(new Joueur("Titi",29, "Irlande"));
        equipe.getListeJoeur().add(new Joueur("Alala",29, "Espagne"));
        Joueur joueur1 = new Joueur("Mathieu",34, "Luxembourg");
        equipe.getListeJoeur().add(joueur1);

        List<Joueur> listJ = new LinkedList<>(equipe.getListeJoeur());
        equipe.printListeJoueur();
        //
        Collections.sort(listJ,Joueur.AGE_COMP);
        printList(listJ);

        Collections.sort(listJ);
        printList(listJ);


        Joueur  j1 = Collections.min(listJ);
        Joueur j2 = Collections.max(listJ);
        System.out.println("nom max "+j1.getName() + " max "+ j2.getName());
        //Collections.shuffle(listJ);
        //Collections.reverse(listJ);
        int indice = Collections.binarySearch(listJ, joueur1);
        System.out.println("indice "+ indice);


    }

    public static int divise1(int x, int y)  throws ArithmeticException {
            return (x / y);
    }

    public static void printList(List<Joueur> list){
        System.out.println(" Liste des joueurs");
        for (Joueur joueur:list){
            System.out.println("\t Nom : "+ joueur.getName() + " / Age : "+joueur.getAge() +" / pays "+joueur.getPays());
        }


    }
}
