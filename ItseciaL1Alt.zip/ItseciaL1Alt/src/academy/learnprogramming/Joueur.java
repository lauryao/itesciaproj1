package academy.learnprogramming;

import java.util.Comparator;

public class Joueur implements Comparable<Joueur> {
    private String name;
    private int age;
    private String pays;

    public Joueur(String name, int age, String pays) {
        this.name = name;
        this.age = age;
        this.pays = pays;
    }

    final static Comparator<Joueur> AGE_COMP = new Comparator<Joueur>() {
        @Override
        public int compare(Joueur joueur1, Joueur joueur2) {
            if (joueur1.getAge() > joueur2.getAge()) {
                return 1;
            } else if (joueur1.getAge() <= joueur2.getAge()) {
                return  -1;
            } else {
                return 0;
            }
        }
    };

    @Override
    public int compareTo(Joueur o) {
        return this.name.compareToIgnoreCase(o.getName());
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getPays() {
        return pays;
    }
}
