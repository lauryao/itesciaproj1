package academy.learnprogramming;

import java.util.ArrayList;
import java.util.List;

public class TeamList {
    private List<String>  list = new ArrayList<>();

    public boolean addTeam(String team){
        if (!team.equals("")) {
            return this.list.add(team);
        } else {
            return false;
        }
    }

    public void printTeamList(){
        System.out.println("**************Liste des equipes*******");
        for (String team:this.list){
            System.out.println("\t"+team);
        }
        System.out.println("****************Fin de la liste***************");
    }


}
