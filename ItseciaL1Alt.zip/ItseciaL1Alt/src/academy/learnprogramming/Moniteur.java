package academy.learnprogramming;

public class Moniteur {
    private String model;
    private String fabriquant;
    private int taille;
    private int resolution;

    public Moniteur(String model, String fabriquant, int taille, int resolution) {
        this.model = model;
        this.fabriquant = fabriquant;
        this.taille = taille;
        this.resolution = resolution;
    }



    public void afficherImage(){
        System.out.println("afficher image");
    }
}
