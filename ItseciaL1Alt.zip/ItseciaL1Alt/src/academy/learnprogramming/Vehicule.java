package academy.learnprogramming;

public interface Vehicule  {
    public abstract void roule();
    public abstract void freiner();
}
