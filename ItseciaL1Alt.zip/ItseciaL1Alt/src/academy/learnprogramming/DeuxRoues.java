package academy.learnprogramming;

public abstract class DeuxRoues implements Vehicule {
    private String name;

    public void printDeuxRoues(){
        System.out.println("Deux roues "+this.name);
    }

    public abstract void planer(int degre);
    public abstract void cabrer();

    //PC : cartemere, Moniteur, alimentation, stockage
    //Classe carteMere : propriétés/méthodes
    //Classe monitor : propriétés
    //Classe stockage : pr

    //Définir chacune des classes avec propriétés et méthodes





}
