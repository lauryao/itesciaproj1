package academy.learnprogramming;

import java.util.HashMap;
import java.util.Map;

public class MapTest {

    public static void main(String[] args) {
        //Declaration
        Map<String, String> map = new HashMap<>();

        //Ajout de couple (cle,valeur) dans le dictionnaire
        map.put("FR","FRANCE");
        map.put("GB","GRANDE BRETAGNE");
        map.put("DE","ALLEMAGNE");

        //recupération
        //String pays = map.get("DE");
        //System.out.println("pays "+pays);

        String ancValeur = map.putIfAbsent("FR","MALAISIE");
        System.out.println("anc val "+ancValeur);

        if (map.replace("FR","FRANCE","FRANCE METROPOLE")) {
            System.out.println("modif effectuee");
        } else {
            System.out.println("modif refusee");
        }

        if (map.containsKey("FR")) {

        }


        //Afficher toutes les valeurs du dictionnaire
        for (String val:map.keySet()){
            System.out.println("cle : "+ val + " valeur : "+map.get(val));
        }










    }
}
